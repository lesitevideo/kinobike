var incr = 0;

var container;


var camera, scene, renderer, effect, controls;
var video;
var sphere, lightMesh, geometry;

var directionalLight, pointLight;

var mouseX = 0,
    mouseY = 0;
var windowHalfX = window.innerWidth / 2;
var windowHalfY = window.innerHeight / 2;


var textureLoader = new THREE.TextureLoader();
var clock = new THREE.Clock();

$(document).ready(function() {
    var innerBounds;
    innerBounds = chrome.app.window.current().innerBounds;
    innerBounds.left = 0;
    innerBounds.top = 0;

    innerBounds.width = screen.width;
    innerBounds.height = screen.height;


    init();
    animate();


});




function init() {

    container = document.createElement('div');
    document.body.appendChild(container);

    camera = new THREE.PerspectiveCamera(120, window.innerWidth / window.innerHeight, 1, 1024);
    camera.position.z = 50;
    camera.target = new THREE.Vector3(0, 0, 0);

    controls = new THREE.DK2Controls(camera);
    scene = new THREE.Scene();


    var geometry = new THREE.SphereGeometry(512, 32, 32);
    geometry.scale(-1, 1, 1);

    video = document.createElement('video');
    //video.width = 2048;
    //video.height = 1024;
    video.autoplay = true;
    video.loop = true;

    video.src = "videos/montage.mp4";
    video.setAttribute('crossorigin', 'anonymous');

    var texture = new THREE.VideoTexture(video);
    texture.minFilter = THREE.LinearFilter;
    texture.format = THREE.RGBFormat;
	texture.generateMipmaps = false;

    var material = new THREE.MeshBasicMaterial({
        map: texture
    });

    sphere = new THREE.Mesh(geometry, material);

    scene.add(sphere);



    renderer = new THREE.WebGLRenderer();

    renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(renderer.domElement);

    effect = new THREE.StereoEffect(renderer);
    effect.setSize(window.innerWidth, window.innerHeight);

    window.addEventListener('resize', onWindowResize, false);
    window.addEventListener('keydown', onKeyDown, false);

}

function onKeyDown(event) {
    switch (event.keyCode) {
        case 82: //R
            sphere.rotation.y += THREE.Math.degToRad(10);
    }
}

function onWindowResize() {

    windowHalfX = window.innerWidth / 2,
        windowHalfY = window.innerHeight / 2,

        camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    effect.setSize(window.innerWidth, window.innerHeight);

}



//

function animate() {

    requestAnimationFrame(animate);

    render();

}

function render() {

    var timer = 0.0001 * Date.now();
    var delta = clock.getDelta();


    //camera.lookAt( camera.target );
    //camera.position.copy( camera.target ).negate();


    controls.update(delta);

    effect.render(scene, camera);

}