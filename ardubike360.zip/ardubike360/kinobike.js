				
				setInterval(function() {
					var strvit = 0;
					var vitesse;
					if( typeof analogPins !== 'undefined' ){
						vitesse = analogPins[0];
					} else {
						vitesse = 0;
					}
					
					strvit = vitesse/14;
					strvit = strvit.toFixed(1);
					if( strvit > 1 ){
						strvit = 1;
					}
					//console.log( strvit );
					
                  if( vitesse*2 < 80 ){
						$(".vitesseleft").html( vitesse*2 + " Km/h");
				  	} else {
						$(".vitesseleft").html();
					}
					$(".vitesseright").html( $(".vitesseleft").html() );
					
					if( sphere.material.map ){
						if(vitesse > 0){
							video.playbackRate = strvit;
							$(".container").css('display','block');
						} else {
							video.playbackRate = 0;
							$(".container").css('display','none');
						}
					}
				}, 50);
			
			

